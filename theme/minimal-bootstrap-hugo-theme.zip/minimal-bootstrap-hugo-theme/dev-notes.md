# Dev Notes

## Run Theme Against Example Site Locally

```
hugo server \
--gc \
--source exampleSite \
--config exampleSite/config.toml \
--themesDir ../.. \
--theme minimal-bootstrap-hugo-theme \
--renderToDisk
```

## Screenshots

Use <https://www.befunky.com/> to crop and resize screenshots